CREATE VIEW `mostbids` AS
  SELECT
    `bucky`.`items`.`id`   AS `id`,
    `bucky`.`items`.`name` AS `name`,
    `bucky`.`items`.`bids` AS `bids`
  FROM `bucky`.`items`
  ORDER BY `bucky`.`items`.`bids` DESC
  LIMIT 10