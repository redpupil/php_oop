CREATE VIEW `mailing` AS
  SELECT concat(`bucky`.`customers`.`city`, ',', `bucky`.`customers`.`state`) AS `adress`
  FROM `bucky`.`customers`